package com.vibra.player

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

private val Back = Color(0xFF090910)
private val Card = Color(0xFF171724)
private val Accent = Color(0xFFB18CFF)
private val Txt = Color(0xFFF7F4FF)
private val Sub = Color(0xFF9894A8)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) setContentViewApp()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            setContentViewApp()
        } else {
            permissionLauncher.launch(permission)
        }
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ controller = controllerFuture?.get() }, ContextCompat.getMainExecutor(this))
    }

    private fun setContentViewApp() {
        val tracks = loadTracks()
        setContent { VibraApp(tracks, onPlay = { index ->
            controller?.let { player ->
                val items = tracks.map { track ->
                    MediaItem.Builder().setUri(track.uri).setMediaMetadata(
                        MediaMetadata.Builder().setTitle(track.title).setArtist(track.artist).build()
                    ).build()
                }
                player.setMediaItems(items, index, 0L)
                player.prepare()
                player.play()
            }
        }, getController = { controller }) }
    }

    private fun loadTracks(): List<Track> {
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result += Track(id, cursor.getString(titleCol) ?: "Без названия", cursor.getString(artistCol) ?: "Неизвестный исполнитель",
                    ContentUris.withAppendedId(collection, id), cursor.getLong(durationCol))
            }
        }
        return result
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
fun VibraApp(tracks: List<Track>, onPlay: (Int) -> Unit, getController: () -> MediaController?) {
    var selectedTab by remember { mutableStateOf("Треки") }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<Long>()) }
    val filtered = tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Back, surface = Card)) {
        Surface(Modifier.fillMaxSize(), color = Back) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(25.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("VIBRA", color = Txt, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                        Text("ТВОЯ МУЗЫКА. ТВОЁ НАСТРОЕНИЕ.", color = Sub, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Card), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Accent)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text(if (selectedTab == "Избранное") "Любимые треки" else "Твоя библиотека", color = Txt, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("${tracks.size} композиций на устройстве", color = Sub, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Card).padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = Sub)
                    Spacer(Modifier.width(10.dp))
                    androidx.compose.foundation.text.BasicTextField(query, { query = it }, modifier = Modifier.weight(1f),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Txt, fontSize = 14.sp), singleLine = true,
                        decorationBox = { inner -> if (query.isEmpty()) Text("Найти песню или исполнителя", color = Sub, fontSize = 14.sp); inner() })
                }
                Spacer(Modifier.height(15.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    FilterChip(selected = selectedTab == "Треки", onClick = { selectedTab = "Треки" }, label = { Text("Все треки") })
                    FilterChip(selected = selectedTab == "Избранное", onClick = { selectedTab = "Избранное" }, label = { Text("♥ Избранное") })
                }
                Spacer(Modifier.height(8.dp))
                val shown = if (selectedTab == "Избранное") filtered.filter { it.id in favorites } else filtered
                if (tracks.isEmpty()) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.LibraryMusic, null, tint = Accent, modifier = Modifier.size(55.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Пока здесь тихо", color = Txt, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Добавь аудиофайлы на телефон и обнови библиотеку", color = Sub, fontSize = 12.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                        itemsIndexed(shown, key = { _, track -> track.id }) { _, track ->
                            TrackRow(track, track.id in favorites, onFavorite = {
                                favorites = if (track.id in favorites) favorites - track.id else favorites + track.id
                            }, onClick = {
                                currentTrack = track
                                onPlay(tracks.indexOf(track))
                                playing = true
                            })
                        }
                    }
                }
                currentTrack?.let { track ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF33264F), Card))).clickable { }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AlbumTile(Modifier.size(46.dp))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(track.title, color = Txt, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                            Text(track.artist, color = Sub, fontSize = 11.sp, maxLines = 1)
                        }
                        IconButton(onClick = {
                            getController()?.let { if (it.isPlaying) it.pause() else it.play() }
                            playing = !playing
                        }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Txt) }
                        IconButton(onClick = { getController()?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Txt) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().padding(bottom = 17.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    BottomItem("Музыка", Icons.Default.MusicNote, true)
                    BottomItem("Альбомы", Icons.Default.Album, false)
                    BottomItem("Плейлисты", Icons.Default.QueueMusic, false)
                }
            }
        }
    }
}

@Composable
fun TrackRow(track: Track, favorite: Boolean, onFavorite: () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumTile(Modifier.size(49.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Accent else Sub, modifier = Modifier.size(20.dp)) }
        Icon(Icons.Default.MoreVert, null, tint = Sub)
    }
    HorizontalDivider(color = Card)
}

@Composable
fun AlbumTile(modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF6D4FA5), Color(0xFF25213C)))), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.GraphicEq, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.size(25.dp))
    }
}

@Composable
fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (active) Accent else Sub)
        Text(label, color = if (active) Accent else Sub, fontSize = 10.sp)
    }
}
