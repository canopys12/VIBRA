package com.vibra.player

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject

data class Track(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val duration: Long)
data class Album(val title: String, val artist: String, val tracks: List<Track>)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val controllerState = mutableStateOf<MediaController?>(null)
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) setContentViewApp() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) setContentViewApp() else permissionLauncher.launch(permission)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ controller = controllerFuture?.get(); controllerState.value = controller }, ContextCompat.getMainExecutor(this))
    }
    private fun setContentViewApp() {
        val tracks = loadTracks()
        val prefs = getSharedPreferences("vibra", MODE_PRIVATE)
        setContent { VibraApp(tracks, prefs, onPlay = { index -> controllerState.value?.let { p ->
            val items = tracks.map { t -> MediaItem.Builder().setMediaId(t.id.toString()).setUri(t.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album).build()).build() }
            p.setMediaItems(items, index, 0L); p.prepare(); p.play()
        } }, controller = controllerState.value) }
    }
    private fun loadTracks(): List<Track> {
        val result = mutableListOf<Track>(); val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM); val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) { val n = c.getLong(id); result += Track(n, c.getString(title) ?: "Без названия", c.getString(artist)?.takeIf { it != "<unknown>" } ?: "Неизвестный исполнитель", c.getString(album)?.takeIf { it != "<unknown>" } ?: "Без альбома", ContentUris.withAppendedId(collection, n), c.getLong(duration)) }
        }; return result
    }
    override fun onDestroy() { controllerFuture?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

private enum class VibraTheme(val label: String) { PURPLE("Фиолетовая"), DARK("Тёмная"), LIGHT("Светлая"), AMOLED("AMOLED") }

@Composable
fun VibraApp(tracks: List<Track>, prefs: android.content.SharedPreferences, onPlay: (Int) -> Unit, controller: MediaController?) {
    var tab by remember { mutableStateOf("Музыка") }; var subTab by remember { mutableStateOf("Все треки") }
    var query by remember { mutableStateOf("") }; var currentTrack by remember { mutableStateOf<Track?>(null) }; var playing by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var themeName by remember { mutableStateOf(prefs.getString("theme", "PURPLE") ?: "PURPLE") }
    var showFullPlayer by remember { mutableStateOf(false) }; var showSettings by remember { mutableStateOf(false) }; var showCreate by remember { mutableStateOf(false) }; var newPlaylist by remember { mutableStateOf("") }
    var playlists by remember { mutableStateOf(loadPlaylists(prefs)) }; var selectedPlaylist by remember { mutableStateOf<String?>(null) }; var selectedAlbum by remember { mutableStateOf<Album?>(null) }
    val theme = VibraTheme.valueOf(themeName)
    // Keep the mini-player synchronized with the actual Media3 playback queue.
    DisposableEffect(controller, tracks) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId?.toLongOrNull()
                currentTrack = tracks.firstOrNull { it.id == id }
                if (currentTrack == null) {
                    val index = controller?.currentMediaItemIndex ?: -1
                    currentTrack = tracks.getOrNull(index)
                }
            }
            override fun onIsPlayingChanged(isPlayingNow: Boolean) { playing = isPlayingNow }
        }
        controller?.addListener(listener)
        if (controller?.currentMediaItem != null) {
            val id = controller.currentMediaItem?.mediaId?.toLongOrNull()
            currentTrack = tracks.firstOrNull { it.id == id } ?: tracks.getOrNull(controller.currentMediaItemIndex)
            playing = controller.isPlaying
        }
        onDispose { controller?.removeListener(listener) }
    }
    fun skipNext() { controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() } }
    fun skipPrevious() { controller?.let { if (it.hasPreviousMediaItem()) it.seekToPreviousMediaItem() else it.seekTo(0) } }
    val bg = when(theme) { VibraTheme.LIGHT -> Color(0xFFF5F3FA); VibraTheme.AMOLED -> Color.Black; else -> Color(0xFF090910) }
    val card = when(theme) { VibraTheme.LIGHT -> Color(0xFFE8E4F0); VibraTheme.AMOLED -> Color(0xFF101014); else -> Color(0xFF171724) }
    val txt = if (theme == VibraTheme.LIGHT) Color(0xFF211C2B) else Color(0xFFF7F4FF)
    val sub = if (theme == VibraTheme.LIGHT) Color(0xFF716B7D) else Color(0xFF9894A8)
    val accent = if (theme == VibraTheme.LIGHT) Color(0xFF7045B5) else Color(0xFFB18CFF)
    val filtered = tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }
    val albums = tracks.groupBy { it.album to it.artist }.map { Album(it.key.first, it.key.second, it.value) }.sortedBy { it.title.lowercase() }
    MaterialTheme(colorScheme = if (theme == VibraTheme.LIGHT) lightColorScheme(primary = accent, background = bg, surface = card) else darkColorScheme(primary = accent, background = bg, surface = card)) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("VIBRA", color = txt, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp); Text("ТВОЯ МУЗЫКА. ТВОЁ НАСТРОЕНИЕ.", color = sub, fontSize = 9.sp, letterSpacing = 1.5.sp) }
                    IconButton(onClick = { showSettings = true }, modifier = Modifier.size(48.dp).clip(CircleShape).background(card)) { Icon(Icons.Default.Tune, null, tint = accent) } }
                Spacer(Modifier.height(22.dp))
                Text(when(tab) { "Альбомы" -> selectedAlbum?.title ?: "Твои альбомы"; "Плейлисты" -> selectedPlaylist ?: "Твои плейлисты"; else -> if (subTab == "Избранное") "Любимые треки" else "Твоя библиотека" }, color = txt, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(when(tab) { "Альбомы" -> selectedAlbum?.let { "${it.artist} · ${it.tracks.size} треков" } ?: "${albums.size} альбомов на устройстве"; "Плейлисты" -> if (selectedPlaylist == null) "${playlists.size} плейлистов" else "${playlists[selectedPlaylist!!].orEmpty().size} композиций"; else -> "${tracks.size} композиций на устройстве" }, color = sub, fontSize = 12.sp)
                Spacer(Modifier.height(17.dp))
                if (tab != "Плейлисты" || selectedPlaylist == null) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(card).padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Search, null, tint = sub); Spacer(Modifier.width(10.dp)); BasicTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, textStyle = TextStyle(color = txt, fontSize = 14.sp), decorationBox = { inner -> if (query.isEmpty()) Text(if (tab == "Альбомы") "Найти альбом или исполнителя" else "Найти песню или исполнителя", color = sub, fontSize = 14.sp); inner() }) }
                }
                Spacer(Modifier.height(12.dp))
                when(tab) {
                    "Музыка" -> { Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { FilterChip(subTab == "Все треки", { subTab = "Все треки" }, label = { Text("Все треки") }); FilterChip(subTab == "Избранное", { subTab = "Избранное" }, label = { Text("♥ Избранное") }) }
                        val shown = if (subTab == "Избранное") filtered.filter { it.id.toString() in favorites } else filtered
                        TrackList(shown, favorites, txt, sub, card, accent, onFavorite = { t -> favorites = if (t.id.toString() in favorites) favorites - t.id.toString() else favorites + t.id.toString(); prefs.edit().putStringSet("favorites", favorites).apply() }, onTrack = { t -> currentTrack = t; onPlay(tracks.indexOf(t)); playing = true }) }
                    "Альбомы" -> if (selectedAlbum != null) { TextButton(onClick = { selectedAlbum = null }) { Icon(Icons.Default.ArrowBack, null); Text("К альбомам") }; TrackList(selectedAlbum!!.tracks, favorites, txt, sub, card, accent, onFavorite = { t -> favorites = if (t.id.toString() in favorites) favorites - t.id.toString() else favorites + t.id.toString(); prefs.edit().putStringSet("favorites", favorites).apply() }, onTrack = { t -> currentTrack = t; onPlay(tracks.indexOf(t)); playing = true }) } else LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) { items(albums.filter { it.title.contains(query, true) || it.artist.contains(query, true) }) { a ->
                        Row(Modifier.fillMaxWidth().clickable { selectedAlbum = a }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { AlbumTile(Modifier.size(62.dp)); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(a.title, color = txt, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(a.artist, color = sub, fontSize = 12.sp); Text("${a.tracks.size} треков", color = accent, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = sub) }; HorizontalDivider(color = card)
                    } }
                    "Плейлисты" -> { if (selectedPlaylist == null) { Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Создать плейлист") }; Spacer(Modifier.height(8.dp)); LazyColumn(Modifier.weight(1f)) { items(playlists.keys.toList()) { name -> Row(Modifier.fillMaxWidth().clickable { selectedPlaylist = name }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) { AlbumTile(Modifier.size(54.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, color = txt, fontWeight = FontWeight.SemiBold); Text("${playlists[name]?.size ?: 0} треков", color = sub, fontSize = 11.sp) }; IconButton(onClick = { playlists = playlists - name; savePlaylists(prefs, playlists) }) { Icon(Icons.Default.DeleteOutline, null, tint = sub) } }; HorizontalDivider(color = card) } } } else { Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = { selectedPlaylist = null }) { Icon(Icons.Default.ArrowBack, null); Text("К плейлистам") }; Spacer(Modifier.weight(1f)); IconButton(onClick = { playlists = playlists - selectedPlaylist!!; savePlaylists(prefs, playlists); selectedPlaylist = null }) { Icon(Icons.Default.DeleteOutline, null, tint = sub) } }; val ids = playlists[selectedPlaylist].orEmpty(); val list = tracks.filter { it.id in ids }; TrackList(list, favorites, txt, sub, card, accent, onFavorite = { t -> favorites = if (t.id.toString() in favorites) favorites - t.id.toString() else favorites + t.id.toString(); prefs.edit().putStringSet("favorites", favorites).apply() }, onTrack = { t -> currentTrack = t; onPlay(tracks.indexOf(t)); playing = true }); Text("Добавить треки", color = accent, fontWeight = FontWeight.Bold); LazyColumn(Modifier.weight(0.7f)) { items(tracks.filter { it.id !in ids }) { t -> Text("＋  ${t.title}  ·  ${t.artist}", color = txt, modifier = Modifier.fillMaxWidth().clickable { playlists = playlists + (selectedPlaylist!! to (ids + t.id)); savePlaylists(prefs, playlists) }.padding(vertical = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis) } } } }
                }
                if (tracks.isEmpty()) { Spacer(Modifier.weight(1f)); Text("Пока здесь тихо — добавь музыку на телефон", color = sub); Spacer(Modifier.weight(1f)) }
                currentTrack?.let { t ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF33264F), card)))
                            .pointerInput(controller, t.id) {
                                var drag = 0f
                                detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                                    if (drag < -65f) skipNext() else if (drag > 65f) skipPrevious()
                                    drag = 0f
                                }, onDragCancel = { drag = 0f })
                            }
                            .clickable { showFullPlayer = true }
                            .padding(10.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumTile(Modifier.size(48.dp)); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.title, color = txt, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(t.artist, color = sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = txt) }
                        IconButton(onClick = { skipNext() }) { Icon(Icons.Default.SkipNext, null, tint = txt) }
                    }
                }
                Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalArrangement = Arrangement.SpaceAround) { BottomItem("Музыка", Icons.Default.MusicNote, tab == "Музыка", accent, sub) { tab = "Музыка"; selectedPlaylist = null; selectedAlbum = null }; BottomItem("Альбомы", Icons.Default.Album, tab == "Альбомы", accent, sub) { tab = "Альбомы"; selectedPlaylist = null; selectedAlbum = null }; BottomItem("Плейлисты", Icons.Default.QueueMusic, tab == "Плейлисты", accent, sub) { tab = "Плейлисты"; selectedPlaylist = null; selectedAlbum = null } }
            }
        }
        if (showFullPlayer && currentTrack != null) {
            Dialog(onDismissRequest = { showFullPlayer = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                val t = currentTrack!!
                Column(Modifier.fillMaxSize().background(bg).pointerInput(controller, t.id) {
                    var drag = 0f
                    detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                        if (drag < -65f) skipNext() else if (drag > 65f) skipPrevious()
                        drag = 0f
                    }, onDragCancel = { drag = 0f })
                }.padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showFullPlayer = false }) { Icon(Icons.Default.KeyboardArrowDown, null, tint = txt) }
                        Text("СЕЙЧАС ИГРАЕТ", color = sub, letterSpacing = 2.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Spacer(Modifier.size(48.dp))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        AlbumTile(Modifier.fillMaxWidth().aspectRatio(1f).padding(12.dp))
                        Spacer(Modifier.height(28.dp))
                        Text(t.title, color = txt, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = sub, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        val durationMs = (controller?.duration ?: 0L).coerceAtLeast(0L)
                        val positionMs = (controller?.currentPosition ?: 0L).coerceAtLeast(0L)
                        Slider(value = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f, onValueChange = { v -> if (durationMs > 0L) controller?.seekTo((durationMs * v).toLong()) })
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { skipPrevious() }, modifier = Modifier.size(58.dp)) { Icon(Icons.Default.SkipPrevious, null, tint = txt, modifier = Modifier.size(34.dp)) }
                            IconButton(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }, modifier = Modifier.size(76.dp).clip(CircleShape).background(accent)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = bg, modifier = Modifier.size(42.dp)) }
                            IconButton(onClick = { skipNext() }, modifier = Modifier.size(58.dp)) { Icon(Icons.Default.SkipNext, null, tint = txt, modifier = Modifier.size(34.dp)) }
                        }
                        Text("Свайпни влево или вправо, чтобы переключить трек", color = sub, fontSize = 11.sp, modifier = Modifier.padding(top = 16.dp))
                    }
                }
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Оформление") }, text = { Column { Text("Выбери тему VIBRA", color = sub); VibraTheme.values().forEach { th -> Row(Modifier.fillMaxWidth().clickable { themeName = th.name; prefs.edit().putString("theme", th.name).apply() }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(themeName == th.name, { themeName = th.name; prefs.edit().putString("theme", th.name).apply() }); Text(th.label) } } } }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Готово") } })
        if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, title = { Text("Новый плейлист") }, text = { OutlinedTextField(newPlaylist, { newPlaylist = it }, label = { Text("Название") }, singleLine = true) }, confirmButton = { TextButton(onClick = { val n = newPlaylist.trim(); if (n.isNotEmpty()) { playlists = playlists + (n to emptyList()); savePlaylists(prefs, playlists); newPlaylist = ""; showCreate = false } }) { Text("Создать") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Отмена") } })
    }
}

@Composable private fun ColumnScope.TrackList(list: List<Track>, favorites: Set<String>, txt: Color, sub: Color, card: Color, accent: Color, onFavorite: (Track) -> Unit, onTrack: (Track) -> Unit) {
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 10.dp)) { items(list, key = { it.id }) { t -> Row(Modifier.fillMaxWidth().clickable { onTrack(t) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { AlbumTile(Modifier.size(49.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(t.title, color = txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(t.artist, color = sub, fontSize = 11.sp, maxLines = 1) }; IconButton(onClick = { onFavorite(t) }) { Icon(if (t.id.toString() in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (t.id.toString() in favorites) accent else sub) } }; HorizontalDivider(color = card) } }
}
@Composable private fun AlbumTile(modifier: Modifier = Modifier) { Box(modifier.clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF7954B8), Color(0xFF25213C)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(25.dp)) } }
@Composable private fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, accent: Color, sub: Color, click: () -> Unit) { Column(Modifier.clickable { click() }.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = if (active) accent else sub); Text(label, color = if (active) accent else sub, fontSize = 10.sp) } }
private fun loadPlaylists(prefs: android.content.SharedPreferences): Map<String, List<Long>> { return try { val o = JSONObject(prefs.getString("playlists", "{}") ?: "{}"); o.keys().asSequence().associateWith { k -> val a = o.getJSONArray(k); (0 until a.length()).map { a.getLong(it) } } } catch (_: Exception) { emptyMap() } }
private fun savePlaylists(prefs: android.content.SharedPreferences, playlists: Map<String, List<Long>>) { val o = JSONObject(); playlists.forEach { (k, v) -> o.put(k, JSONArray(v)) }; prefs.edit().putString("playlists", o.toString()).apply() }
