# VIBRA — Android music player

A native Android starter project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Features
- Reads audio tracks indexed by Android MediaStore
- Requests audio library permission
- Plays selected local tracks with ExoPlayer through MediaSessionService
- Basic track search
- Favorites for the current app session
- Compact playback controls

## Build
Open the project folder in Android Studio, use JDK 17, install Android SDK 35, sync Gradle and run on an Android 8.0+ device.

## Current MVP limitations
- Favorites are in-memory and reset when the app process is closed.
- Album artwork, playlist editing, persistent library refresh, equalizer and sleep timer are not implemented yet.
- Playback is local-file playback; there is no streaming catalogue or online account.
