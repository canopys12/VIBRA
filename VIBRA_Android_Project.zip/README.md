# VIBRA Android

Android music player built with Kotlin, Jetpack Compose and AndroidX Media3.

## Playback update
- Mini-player tap opens the expanded Now Playing screen.
- Horizontal swipe left/right in the mini-player or expanded player skips to next/previous track.
- Playback controls use Media3 directly.
- Mini-player title and artist follow Media3 media-item transitions, including automatic next-track changes.
- Media items carry their MediaStore ID so the active track can be matched reliably.

Build with the repository's GitHub Actions workflow (`gradle assembleDebug`) using JDK 17 and Android SDK 35.
